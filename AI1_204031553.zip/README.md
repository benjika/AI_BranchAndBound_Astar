# AI_BranchAndBound_A*
Assignment from AI course with Prof. Roei Zivan. Implementing Branch And Bound and A* algorithms for 8-tile problem.
